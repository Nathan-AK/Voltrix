import pymysql
from website.config import Config

class Database:
    def connect(self):
        return pymysql.connect(host="localhost", 
                               user="root", 
                               password=Config.password, 
                               database="rpms_db", 
                               charset='utf8mb4', 
                               cursorclass=pymysql.cursors.DictCursor)

    def get_users(self, user_id=None):
        con = self.connect()
        cursor = con.cursor(pymysql.cursors.DictCursor)
        try:
            if user_id is None:
                cursor.execute("SELECT * FROM users ORDER BY username ASC")
            else:
                cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
            return cursor.fetchall()
        except Exception as e:
            print("Error get_users:", e)
            return []
        finally:
            con.close()

    def insert_user(self, data):
        con = self.connect()
        cursor = con.cursor()
        try:
            cursor.execute(
                "INSERT INTO users(username, password, email) VALUES (%s, %s, %s)",
                (data['username'], data['password'], data['email'])
            )
            con.commit()
            return True
        except Exception as e:
            print("Error insert_user:", e)
            con.rollback()
            return False
        finally:
            con.close()

    def get_papers(self, paper_id=None):
        con = self.connect()
        cursor = con.cursor()
        try:
            if paper_id is None:
                cursor.execute("SELECT * FROM papers ORDER BY title ASC")
            else:
                cursor.execute("SELECT * FROM papers WHERE id = %s", (paper_id,))
            return cursor.fetchall()
        except Exception as e:
            print("Error get_papers:", e)
            return []
        finally:
            con.close()

    def insert_paper(self, data):
        con = self.connect()
        cursor = con.cursor()
        try:
            cursor.execute(
                "INSERT INTO papers(title, authors, abstract, topics, user_id) VALUES (%s, %s, %s, %s, %s)",
                (data['title'], data['authors'], data['abstract'], data['topics'], data['user_id'])
            )
            con.commit()
            return True
        except Exception as e:
            print("Error insert_paper:", e)
            con.rollback()
            return False
        finally:
            con.close()

    def update_paper(self, paper_id, data):
        con = self.connect()
        cursor = con.cursor()
        try:
            cursor.execute(
                "UPDATE papers SET title = %s, authors = %s, abstract = %s, topics = %s WHERE id = %s",
                (data['title'], data['authors'], data['abstract'], data['topics'], paper_id)
            )
            con.commit()
            return True
        except Exception as e:
            print("Error update_paper:", e)
            con.rollback()
            return False
        finally:
            con.close()

    def delete_paper(self, paper_id):
        con = self.connect()
        cursor = con.cursor()
        try:
            cursor.execute("DELETE FROM papers WHERE id = %s", (paper_id,))
            con.commit()
            return True
        except Exception as e:
            print("Error delete_paper:", e)
            con.rollback()
            return False
        finally:
            con.close()
