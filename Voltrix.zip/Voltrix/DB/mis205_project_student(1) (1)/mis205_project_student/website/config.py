class Config:
    password = ''