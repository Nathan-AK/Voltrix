from flask import Blueprint, flash, render_template, redirect, url_for, request, session
from website.models import Database
import pymysql

db = Database()
con = db.connect()
cursor = con.cursor(pymysql.cursors.DictCursor)  # DictCursor for dict-like results

views = Blueprint('views', __name__)


@views.route('/')
def home():
    # Check if user is logged in
    if 'loggedin' in session:
        # User is logged in, show them the home page
        return render_template('home/home.html', username=session['username'], title="Home")
    # User is not logged in, redirect to login page
    return redirect(url_for('auth.login'))    


@views.route('/profile')
def profile():
    # Check if user is logged in
    if 'loggedin' in session:
        # User is logged in, show them the profile page
        return render_template('auth/profile.html', account=session['account'], title="Profile")
    # User is not logged in, redirect to login page
    return redirect(url_for('auth.login'))  


@views.route('/add_paper', methods=['GET', 'POST'])
def add_paper():
    # Check if user is logged in
    if 'loggedin' not in session:
        # User is not logged in, redirect to login page
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        title = request.form['title']
        authors = request.form['authors']
        abstract = request.form['abstract']
        topics = request.form['topics']

        # Validate form data
        if not title or not authors or not abstract or not topics:
            flash("Please fill out all fields.", "danger")
            return render_template('home/add_paper.html')

        try:
            # Insert paper into the database
            cursor.execute("""
                INSERT INTO papers (title, authors, abstract, topics, user_id)
                VALUES (%s, %s, %s, %s, %s)
            """, (title, authors, abstract, topics, session['id']))
            con.commit()
            flash("Paper added successfully!", "success")
            return redirect(url_for('views.list_papers'))
        except Exception as e:
            flash(f"Failed to add paper: {str(e)}", "danger")

    return render_template('home/add_paper.html')


@views.route('/list_papers', methods=['GET', 'POST'])
def list_papers():
    # Check if user is logged in
    if 'loggedin' not in session:
        # User is not logged in, redirect to login page
        return redirect(url_for('auth.login'))

    # Get search query if submitted
    search_query = request.form.get('search') if request.method == 'POST' else None

    try:
        # Handle delete request
        if request.method == 'POST' and 'delete_id' in request.form:
            paper_id = request.form['delete_id']
            cursor.execute("DELETE FROM papers WHERE paper_id = %s", (paper_id))
            con.commit()
            flash("Paper deleted successfully.", "success")

        # Fetch papers based on search query or all if no query
        if search_query:
            cursor.execute("""
                SELECT * FROM papers
                WHERE user_id = %s AND 
                (title LIKE %s OR authors LIKE %s OR topics LIKE %s)
            """, (session['id'], f"%{search_query}%", f"%{search_query}%", f"%{search_query}%"))
        else:
            cursor.execute("SELECT * FROM papers WHERE user_id = %s", (session['id'],))

        papers = cursor.fetchall()

        print(f"DEBUG: Fetched papers = {papers}")  # debug print

    except Exception as e:
        flash(f"Failed to process request: {str(e)}", "danger")
        papers = []

    # Render template with the list of papers
    return render_template('home/list_papers.html', papers=papers, title="Your Papers")
