from flask import Blueprint, request, session, url_for, render_template, redirect, flash
from website.models import Database
import re

auth = Blueprint('auth', __name__)

db = Database()
con = db.connect()
cursor = con.cursor()

# http://localhost:5000/pythonlogin/ - this will be the login page, we need to use both GET and POST requests
@auth.route('/pythonlogin/', methods=['GET', 'POST'])
def login():
    # Output message if something goes wrong...
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        # Check if account exists using MySQL
        # Fill in here
        cursor.execute('SELECT * FROM users WHERE username = %s AND password = %s', (username, password))
        # Fetch one record and return result
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes. 
            session['loggedin'] = True
            # Fill in here put username, id , account in session
            session['id'] = account['user_id']
            session['username'] = account['username']
            session['account'] = {
                'username': account['username'],
                'password': account['password'],
                'email': account['email']
            }
            # Redirect to home page
            return redirect(url_for('views.home'))
        else:
            # Account doesnt exist or username/password incorrect
            flash("Incorrect username/password!", "danger")
    return render_template('auth/login.html', title="Login")


# http://localhost:5000/pythonlogin/register 
# This will be the registration page, we need to use both GET and POST requests
@auth.route('/pythonlogin/register', methods=['GET', 'POST'])
def register():
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        # Check if account exists using MySQL
        # Fill in here
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        account = cursor.fetchone()
        # If account exists show error and validation checks
        if account:
            flash("Account already exists!", "danger")
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            flash("Invalid email address!", "danger")
        elif not re.match(r'[A-Za-z0-9]+', username):
            flash("Username must contain only characters and numbers!", "danger")
        elif not username or not password or not email:
            flash("Incorrect username/password!", "danger")
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            # Fill in here
            cursor.execute("INSERT INTO users (username, password, email) VALUES (%s, %s, %s)", (username, password, email))
            con.commit()
            flash("You have successfully registered!", "success")
            return redirect(url_for('auth.login'))

    elif request.method == 'POST':
        # Form is empty... (no POST data)
        flash("Please fill out the form!", "danger")
    # Show registration form with message (if any)
    return render_template('auth/register.html', title="Register")


@auth.route('/logout')
def logout():
    # Remove session data, this will log the user out
    # Fill in here
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    session.pop('account', None)
    # Redirect to the login page
    return redirect(url_for('auth.login'))
