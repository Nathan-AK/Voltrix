// Ganti data lokal dengan fetch dari API
fetch('https://example.com/api/lokasi')
  .then(response => response.json())
  .then(data => {
    data.forEach(lokasi => {
      L.marker([lokasi.lat, lokasi.lng])
        .addTo(map)
        .bindPopup(`<b>${lokasi.name}</b>`);
    });
  })
  .catch(error => {
    console.error("Gagal memuat data:", error);
  });